/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alanm
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// File Name SendEmail.java

    import java.util.*;  
    import javax.mail.*;  
    import javax.mail.internet.*;  
    import javax.activation.*;  
      
    public class HomeSecurityEmail  
    {  
     public static void main(String [] args){  
          String to = "alan.morrissey16@gmail.com";//change accordingly  
          String from = "K00205588@student.lit.ie";//change accordingly  
          String host = "jdbc:mysql://oursystem.mysql.database.azure.com:3306/projectdb??useSSL=true&requireSSL=false";//or IP address  
      
         //Get the session object  
          Properties properties = System.getProperties();  
          properties.setProperty("mail.smtp.host", host);  
          Session session = Session.getDefaultInstance(properties);  
      
         //compose the message  
          try{  
             MimeMessage message = new MimeMessage(session);  
             message.setFrom(new InternetAddress(from));  
             message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
             message.setSubject("Registration");  
             message.setText("Registration Successful!  ");  
      
             // Send message  
             Transport.send(message);  
             System.out.println("message sent successfully....");  
      
          }catch (MessagingException mex) {mex.printStackTrace();}  
       }  
    }  